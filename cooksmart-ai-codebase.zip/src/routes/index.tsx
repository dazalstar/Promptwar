import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useRef } from "react";
import { ChefHat, Sparkles, Wallet, Leaf } from "lucide-react";
import { generatePlan, type Plan, type Preferences } from "@/lib/plan.functions";
import { PreferencesForm } from "@/components/cooksmart/PreferencesForm";
import { Results } from "@/components/cooksmart/Results";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CookSmart AI — Your Personal AI Cooking Planner" },
      { name: "description", content: "Generate a personalized daily meal plan, grocery list, and budget-aware cooking checklist powered by AI." },
      { property: "og:title", content: "CookSmart AI — Your Personal AI Cooking Planner" },
      { property: "og:description", content: "AI-powered daily meal plans, grocery lists, substitutions, and budget tracking." },
    ],
  }),
  component: Index,
});

function Index() {
  const planFn = useServerFn(generatePlan);
  const formRef = useRef<HTMLDivElement>(null);
  const mutation = useMutation<Plan, Error, Preferences>({
    mutationFn: (data) => planFn({ data }),
  });

  const scrollToForm = () =>
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -left-40 top-0 h-[500px] w-[500px] rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute -right-40 top-40 h-[500px] w-[500px] rounded-full bg-success/10 blur-[120px]" />
      </div>

      <header className="no-print mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground">
            <ChefHat className="h-5 w-5" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight">CookSmart <span className="text-primary">AI</span></span>
        </div>
        <span className="hidden text-xs text-muted-foreground sm:inline">Powered by Lovable AI</span>
      </header>

      <section className="no-print mx-auto max-w-6xl px-5 pb-10 pt-6 text-center sm:pt-12">
        <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary">
          <Sparkles className="h-3.5 w-3.5" /> Your Personal AI Cooking Coach
        </div>
        <h1 className="mx-auto max-w-3xl font-display text-4xl font-black leading-[1.05] tracking-tight sm:text-6xl">
          Your Personal <span className="text-primary">AI Cooking</span> Planner
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-balance text-base text-muted-foreground sm:text-lg">
          CookSmart AI isn't just a recipe app. It's a personal cooking coach that adapts to your budget, geography, and cuisine preferences — helping you eat better, spend smarter, and waste less.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <button
            onClick={scrollToForm}
            className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-6 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition hover:opacity-90"
          >
            <Sparkles className="h-5 w-5" /> Generate Today's Plan
          </button>
        </div>
        <div className="mx-auto mt-10 grid max-w-3xl gap-3 sm:grid-cols-3">
          <Stat icon={<ChefHat className="h-4 w-4" />} text="3 meals planned" />
          <Stat icon={<Wallet className="h-4 w-4" />} text="Budget-aware" />
          <Stat icon={<Leaf className="h-4 w-4" />} text="Waste-reducing" />
        </div>
      </section>

      <section ref={formRef} className="mx-auto max-w-6xl px-5 pb-20">
        {!mutation.data && (
          <div className="mx-auto max-w-3xl">
            <h2 className="mb-1 font-display text-2xl font-bold">Your preferences</h2>
            <p className="mb-5 text-sm text-muted-foreground">
              Fill these out — Gemini will generate your full cooking day.
            </p>
            <PreferencesForm
              loading={mutation.isPending}
              onSubmit={(p) => mutation.mutate(p)}
            />
            {mutation.isError && (
              <p className="mt-4 rounded-lg bg-destructive/15 p-3 text-sm text-destructive">
                Something went wrong: {mutation.error.message}
              </p>
            )}
          </div>
        )}

        {mutation.data && mutation.variables && (
          <Results
            plan={mutation.data}
            prefs={mutation.variables}
            onReset={() => { mutation.reset(); scrollToForm(); }}
          />
        )}
      </section>

      <footer className="no-print mx-auto max-w-6xl px-5 py-6 text-center text-xs text-muted-foreground">
        Built with Lovable · CookSmart AI
      </footer>
    </main>
  );
}

function Stat({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center justify-center gap-2 rounded-xl border border-border/60 bg-card/40 px-4 py-2 text-sm text-foreground/90 backdrop-blur">
      <span className="text-primary">{icon}</span>{text}
    </div>
  );
}
