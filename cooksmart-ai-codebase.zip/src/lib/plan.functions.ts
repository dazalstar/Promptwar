import { createServerFn } from "@tanstack/react-start";
import { generateText, Output } from "ai";
import { z } from "zod";

export const PreferencesSchema = z.object({
  budget: z.number().min(0),
  currency: z.string().default("USD"),
  people: z.number().int().min(1).max(20),
  country: z.string().default(""),
  diet: z.string(),
  allergies: z.string().default(""),
  cuisines: z.string().default(""),
  skill: z.string(),
  time: z.string(),
  pantry: z.string().default(""),
});

export type Preferences = z.infer<typeof PreferencesSchema>;

const MealSchema = z.object({
  name: z.string(),
  ingredients: z.array(z.object({ item: z.string(), qty: z.string() })),
  steps: z.array(z.string()),
  prepTime: z.string(),
  cost: z.number(),
});

const PlanSchema = z.object({
  meals: z.object({
    breakfast: MealSchema,
    lunch: MealSchema,
    dinner: MealSchema,
  }),
  grocery: z.array(
    z.object({
      category: z.string(),
      item: z.string(),
      quantity: z.string(),
      cost: z.number(),
    }),
  ),
  substitutions: z.array(
    z.object({
      ingredient: z.string(),
      alternatives: z.array(z.string()),
    }),
  ),
  budget: z.object({
    totalCost: z.number(),
    status: z.enum(["within", "close", "over"]),
    advice: z.string(),
  }),
  checklist: z.object({
    morning: z.array(z.string()),
    lunch: z.array(z.string()),
    evening: z.array(z.string()),
  }),
  tips: z.object({
    savings: z.array(z.string()),
    waste: z.array(z.string()),
  }),
});

export type Plan = z.infer<typeof PlanSchema>;

function fallbackPlan(p: Preferences): Plan {
  return {
    meals: {
      breakfast: {
        name: "Oats & Banana Bowl",
        ingredients: [
          { item: "Rolled oats", qty: "1 cup" },
          { item: "Banana", qty: "1" },
          { item: "Milk", qty: "1 cup" },
          { item: "Honey", qty: "1 tbsp" },
        ],
        steps: ["Boil milk", "Add oats, cook 5 min", "Top with banana & honey"],
        prepTime: "10 min",
        cost: 2.5,
      },
      lunch: {
        name: "Veggie Rice Bowl",
        ingredients: [
          { item: "Rice", qty: "1 cup" },
          { item: "Mixed vegetables", qty: "2 cups" },
          { item: "Soy sauce", qty: "2 tbsp" },
          { item: "Garlic", qty: "2 cloves" },
        ],
        steps: ["Cook rice", "Sauté garlic & veggies", "Toss with soy sauce"],
        prepTime: "25 min",
        cost: 4.0,
      },
      dinner: {
        name: "Lentil Soup & Bread",
        ingredients: [
          { item: "Lentils", qty: "1 cup" },
          { item: "Onion", qty: "1" },
          { item: "Tomato", qty: "2" },
          { item: "Bread", qty: "2 slices" },
        ],
        steps: ["Sauté onion & tomato", "Add lentils + water, simmer 25 min", "Serve with bread"],
        prepTime: "35 min",
        cost: 3.5,
      },
    },
    grocery: [
      { category: "Pantry", item: "Rolled oats", quantity: "1 cup", cost: 0.5 },
      { category: "Pantry", item: "Rice", quantity: "1 cup", cost: 0.7 },
      { category: "Pantry", item: "Lentils", quantity: "1 cup", cost: 0.8 },
      { category: "Pantry", item: "Bread", quantity: "1 loaf", cost: 1.5 },
      { category: "Vegetables", item: "Mixed vegetables", quantity: "2 cups", cost: 2.0 },
      { category: "Vegetables", item: "Onion", quantity: "1", cost: 0.3 },
      { category: "Vegetables", item: "Tomato", quantity: "2", cost: 0.6 },
      { category: "Vegetables", item: "Garlic", quantity: "1 bulb", cost: 0.4 },
      { category: "Fruits", item: "Banana", quantity: "1", cost: 0.3 },
      { category: "Dairy", item: "Milk", quantity: "1 cup", cost: 0.6 },
      { category: "Other", item: "Honey", quantity: "1 tbsp", cost: 0.3 },
      { category: "Other", item: "Soy sauce", quantity: "2 tbsp", cost: 0.2 },
    ],
    substitutions: [
      { ingredient: "Milk", alternatives: ["Oat milk", "Soy milk", "Almond milk"] },
      { ingredient: "Rice", alternatives: ["Quinoa", "Couscous", "Bulgur"] },
      { ingredient: "Lentils", alternatives: ["Chickpeas", "Black beans", "Split peas"] },
      { ingredient: "Honey", alternatives: ["Maple syrup", "Agave", "Brown sugar"] },
    ],
    budget: {
      totalCost: 10.0,
      status: p.budget >= 12 ? "within" : p.budget >= 9 ? "close" : "over",
      advice: "Reuse onion & tomato across lunch and dinner to reduce waste and save money.",
    },
    checklist: {
      morning: ["Buy ingredients", "Prep vegetables", "Soak lentils"],
      lunch: ["Cook lunch", "Store leftovers in fridge"],
      evening: ["Prepare dinner", "Pack leftovers for tomorrow"],
    },
    tips: {
      savings: [
        "Buy seasonal vegetables to cut grocery cost",
        "Replace expensive proteins with lentils or beans",
        "Buy rice and oats in bulk",
      ],
      waste: [
        "Use leftover veggies in dinner soup",
        "Repurpose lunch rice as breakfast porridge",
        "Freeze extra bread before it spoils",
      ],
    },
  };
}

export const generatePlan = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => PreferencesSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return fallbackPlan(data);

    try {
      const { createLovableAiGatewayProvider } = await import("./ai-gateway.server");
      const gateway = createLovableAiGatewayProvider(key);
      const model = gateway("google/gemini-3-flash-preview");

      const prompt = `You are CookSmart AI, a personal cooking coach that adapts to budget, geography, and cuisine preferences.
Generate a complete daily cooking plan for ${data.people} people with these preferences:
- Country / location: ${data.country || "unspecified"}
- Daily budget: ${data.budget} ${data.currency}
- Diet: ${data.diet}
- Allergies: ${data.allergies || "none"}
- Preferred cuisines: ${data.cuisines || "any"}
- Cooking skill: ${data.skill}
- Available cooking time: ${data.time}
- Ingredients already at home: ${data.pantry || "none"}

Rules:
- Adapt dishes to local availability and cultural relevance for ${data.country || "the user's region"}. Use ingredients that are realistically sold in local markets/supermarkets there, and reflect typical local prices in ${data.currency}.
- Suggest authentic, recognizable recipes from the user's preferred cuisines (e.g., Thai, Mexican, Italian, Indian, Jain, Mediterranean) when provided. Use correct dish names and traditional ingredients/techniques.
- The grocery list should use item names, units, and quantities that match local shopping habits for ${data.country || "the user's region"}.
- All costs are in ${data.currency}.
- Total cost of all meals + grocery should respect the budget when possible.
- Set budget.status to "within" if totalCost <= ${data.budget * 0.9}, "close" if <= ${data.budget}, otherwise "over".
- If "over", populate budget.advice with concrete cheaper-ingredient or quantity-reduction suggestions and adjust the plan to be cheaper.
- Group grocery items in one of: Vegetables, Fruits, Dairy, Meat, Pantry, Spices, Other.
- Provide substitutions for at least 4 key ingredients (budget-friendly, allergy-friendly, and locally available).
- Provide a practical checklist for morning, lunch prep, and evening.
- Provide 3 money-saving tips and 3 food-waste-reduction tips.`;

      const { experimental_output } = await generateText({
        model,
        prompt,
        experimental_output: Output.object({ schema: PlanSchema }),
      });
      return experimental_output as Plan;
    } catch (err) {
      console.error("generatePlan AI error", err);
      return fallbackPlan(data);
    }
  });
