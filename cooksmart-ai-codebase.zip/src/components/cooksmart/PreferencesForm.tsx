import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import type { Preferences } from "@/lib/plan.functions";
import { Loader2, Sparkles } from "lucide-react";

interface Props {
  onSubmit: (p: Preferences) => void;
  loading: boolean;
}

export function PreferencesForm({ onSubmit, loading }: Props) {
  const [budget, setBudget] = useState(15);
  const [currency, setCurrency] = useState("USD");
  const [people, setPeople] = useState(2);
  const [country, setCountry] = useState("");
  const [diet, setDiet] = useState("Vegetarian");
  const [allergies, setAllergies] = useState("");
  const [cuisines, setCuisines] = useState("");
  const [skill, setSkill] = useState("Beginner");
  const [time, setTime] = useState("30-60 min");
  const [pantry, setPantry] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ budget, currency, people, country, diet, allergies, cuisines, skill, time, pantry });
      }}
      className="grid gap-5 rounded-3xl border border-border/60 bg-card/60 p-6 backdrop-blur sm:p-8"
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Daily budget">
          <Input
            type="number" min={1} value={budget}
            onChange={(e) => setBudget(Number(e.target.value))}
            required
          />
        </Field>
        <Field label="Currency">
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["USD", "EUR", "GBP", "INR", "AUD", "CAD"].map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Number of people">
          <Input type="number" min={1} max={20} value={people}
            onChange={(e) => setPeople(Number(e.target.value))} />
        </Field>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Dietary preference">
          <Select value={diet} onValueChange={setDiet}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["Vegetarian", "Vegan", "Non-Vegetarian", "Keto", "High Protein"].map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Cooking skill">
          <Select value={skill} onValueChange={setSkill}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["Beginner", "Intermediate", "Advanced"].map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Available time">
          <Select value={time} onValueChange={setTime}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["< 30 min", "30-60 min", "1-2 hours", "Unlimited"].map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </div>

      <Field label="Allergies (comma-separated)">
        <Input value={allergies} onChange={(e) => setAllergies(e.target.value)}
          placeholder="peanuts, gluten, shellfish..." />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Your country / region">
          <Input value={country} onChange={(e) => setCountry(e.target.value)}
            placeholder="India, USA, Thailand, Italy..." />
        </Field>
        <Field label="Preferred cuisines">
          <Input value={cuisines} onChange={(e) => setCuisines(e.target.value)}
            placeholder="Thai, Mexican, Italian, Jain..." />
        </Field>
      </div>
      <Field label="Ingredients you already have">
        <Textarea value={pantry} onChange={(e) => setPantry(e.target.value)}
          placeholder="rice, eggs, onion, garlic, olive oil..." rows={3} />
      </Field>

      <Button
        type="submit" disabled={loading} size="lg"
        className="mt-2 h-12 rounded-xl text-base font-semibold"
      >
        {loading ? (
          <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Cooking up your plan…</>
        ) : (
          <><Sparkles className="mr-2 h-5 w-5" />Generate Today's Plan</>
        )}
      </Button>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-2">
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}
