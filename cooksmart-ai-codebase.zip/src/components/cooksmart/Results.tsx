import { useMemo, useState } from "react";
import type { Plan, Preferences } from "@/lib/plan.functions";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  ChefHat, ShoppingBasket, Wallet, ListChecks, Lightbulb, Replace,
  Clock, Coins, Download, Printer, FileText, Sun, Sunset, Moon,
} from "lucide-react";
import { downloadPlanPdf, downloadGroceryTxt } from "./exportUtils";

export function Results({ plan, prefs, onReset }: { plan: Plan; prefs: Preferences; onReset: () => void }) {
  const currency = prefs.currency;
  return (
    <div className="grid gap-6">
      <ExportBar plan={plan} prefs={prefs} onReset={onReset} />
      <BudgetDashboard plan={plan} prefs={prefs} />

      <section className="grid gap-4 md:grid-cols-3">
        <MealCard icon={<Sun className="h-5 w-5" />} label="Breakfast" meal={plan.meals.breakfast} currency={currency} />
        <MealCard icon={<Sunset className="h-5 w-5" />} label="Lunch" meal={plan.meals.lunch} currency={currency} />
        <MealCard icon={<Moon className="h-5 w-5" />} label="Dinner" meal={plan.meals.dinner} currency={currency} />
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <GroceryList plan={plan} currency={currency} />
        <CookingChecklist plan={plan} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <SubstitutionsPanel plan={plan} />
        <TipsPanel plan={plan} />
      </div>
    </div>
  );
}

function SectionCard({
  icon, title, accent, children, className = "",
}: { icon: React.ReactNode; title: string; accent?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-3xl border border-border/60 bg-card/60 p-6 backdrop-blur ${className}`}>
      <div className="mb-5 flex items-center gap-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
          {icon}
        </div>
        <div className="min-w-0">
          <h3 className="truncate font-display text-lg font-bold">{title}</h3>
          {accent && <p className="text-xs text-muted-foreground">{accent}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

function MealCard({ icon, label, meal, currency }: { icon: React.ReactNode; label: string; meal: Plan["meals"]["breakfast"]; currency: string }) {
  return (
    <SectionCard icon={icon} title={label} accent={meal.name}>
      <div className="mb-4 flex flex-wrap gap-2 text-xs">
        <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" />{meal.prepTime}</Badge>
        <Badge variant="secondary" className="gap-1"><Coins className="h-3 w-3" />{currency} {meal.cost.toFixed(2)}</Badge>
      </div>
      <div className="mb-4">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ingredients</p>
        <ul className="space-y-1 text-sm">
          {meal.ingredients.map((i, idx) => (
            <li key={idx} className="flex justify-between gap-2">
              <span className="text-foreground/90">{i.item}</span>
              <span className="shrink-0 text-muted-foreground">{i.qty}</span>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Steps</p>
        <ol className="space-y-1.5 text-sm">
          {meal.steps.map((s, idx) => (
            <li key={idx} className="flex gap-2">
              <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/20 text-[10px] font-bold text-primary">{idx + 1}</span>
              <span className="text-foreground/90">{s}</span>
            </li>
          ))}
        </ol>
      </div>
    </SectionCard>
  );
}

function BudgetDashboard({ plan, prefs }: { plan: Plan; prefs: Preferences }) {
  const total = plan.budget.totalCost;
  const pct = Math.min(100, Math.round((total / prefs.budget) * 100));
  const remaining = prefs.budget - total;
  const statusMap = {
    within: { label: "Within Budget", color: "text-success", bg: "bg-success/15", bar: "bg-success" },
    close: { label: "Close to Budget", color: "text-warning", bg: "bg-warning/15", bar: "bg-warning" },
    over: { label: "Over Budget", color: "text-destructive", bg: "bg-destructive/15", bar: "bg-destructive" },
  } as const;
  const s = statusMap[plan.budget.status];
  return (
    <SectionCard icon={<Wallet className="h-5 w-5" />} title="Budget Dashboard" accent="Daily spend overview">
      <div className="grid gap-4 sm:grid-cols-3">
        <Metric label="Daily Budget" value={`${prefs.currency} ${prefs.budget.toFixed(2)}`} />
        <Metric label="Estimated Spend" value={`${prefs.currency} ${total.toFixed(2)}`} />
        <Metric label={remaining >= 0 ? "Remaining" : "Over by"} value={`${prefs.currency} ${Math.abs(remaining).toFixed(2)}`} />
      </div>
      <div className="mt-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className={`rounded-full px-3 py-1 text-xs font-bold ${s.bg} ${s.color}`}>{s.label}</span>
          <span className="text-muted-foreground">{pct}% of budget</span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
          <div className={`h-full ${s.bar} transition-all`} style={{ width: `${pct}%` }} />
        </div>
        {plan.budget.advice && (
          <p className="mt-4 rounded-xl bg-accent/30 p-3 text-sm text-foreground/90">
            <span className="font-semibold text-primary">AI advice: </span>{plan.budget.advice}
          </p>
        )}
      </div>
    </SectionCard>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-secondary/50 p-4">
      <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold">{value}</p>
    </div>
  );
}

function GroceryList({ plan, currency }: { plan: Plan; currency: string }) {
  const grouped = useMemo(() => {
    const m = new Map<string, Plan["grocery"]>();
    for (const g of plan.grocery) {
      if (!m.has(g.category)) m.set(g.category, []);
      m.get(g.category)!.push(g);
    }
    return Array.from(m.entries());
  }, [plan.grocery]);
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const total = plan.grocery.reduce((s, g) => s + g.cost, 0);
  return (
    <SectionCard icon={<ShoppingBasket className="h-5 w-5" />} title="Grocery List" accent={`Total: ${currency} ${total.toFixed(2)}`}>
      <div className="space-y-5">
        {grouped.map(([cat, items]) => (
          <div key={cat}>
            <p className="mb-2 text-xs font-bold uppercase tracking-wider text-primary">{cat}</p>
            <ul className="space-y-1.5">
              {items.map((g, i) => {
                const id = `${cat}-${i}-${g.item}`;
                const isChecked = checked.has(id);
                return (
                  <li key={id} className="flex items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-secondary/40">
                    <Checkbox
                      checked={isChecked}
                      onCheckedChange={() => {
                        const next = new Set(checked);
                        if (isChecked) next.delete(id); else next.add(id);
                        setChecked(next);
                      }}
                    />
                    <span className={`flex-1 text-sm ${isChecked ? "text-muted-foreground line-through" : ""}`}>
                      {g.item}
                    </span>
                    <span className="shrink-0 text-xs text-muted-foreground">{g.quantity}</span>
                    <span className="shrink-0 text-xs font-medium tabular-nums">{currency} {g.cost.toFixed(2)}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

function CookingChecklist({ plan }: { plan: Plan }) {
  const sections: Array<[string, string[], React.ReactNode]> = [
    ["Morning", plan.checklist.morning, <Sun key="m" className="h-4 w-4 text-warning" />],
    ["Lunch Prep", plan.checklist.lunch, <Sunset key="l" className="h-4 w-4 text-primary" />],
    ["Evening", plan.checklist.evening, <Moon key="e" className="h-4 w-4 text-foreground/70" />],
  ];
  const [done, setDone] = useState<Set<string>>(new Set());
  return (
    <SectionCard icon={<ListChecks className="h-5 w-5" />} title="Daily Cooking To-Do" accent="Tap to check off tasks">
      <div className="space-y-5">
        {sections.map(([label, tasks, icon]) => (
          <div key={label}>
            <p className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
              {icon}{label}
            </p>
            <ul className="space-y-1.5">
              {tasks.map((t, i) => {
                const id = `${label}-${i}`;
                const d = done.has(id);
                return (
                  <li key={id}>
                    <button
                      type="button"
                      onClick={() => {
                        const n = new Set(done);
                        if (d) n.delete(id); else n.add(id);
                        setDone(n);
                      }}
                      className="flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left text-sm hover:bg-secondary/40"
                    >
                      <Checkbox checked={d} />
                      <span className={d ? "text-muted-foreground line-through" : ""}>{t}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </SectionCard>
  );
}

function SubstitutionsPanel({ plan }: { plan: Plan }) {
  return (
    <SectionCard icon={<Replace className="h-5 w-5" />} title="Ingredient Substitutions" accent="Budget & allergy-friendly swaps">
      <ul className="space-y-3">
        {plan.substitutions.map((s, i) => (
          <li key={i} className="rounded-2xl bg-secondary/40 p-3">
            <p className="mb-1.5 text-sm font-semibold">{s.ingredient}</p>
            <div className="flex flex-wrap gap-1.5">
              {s.alternatives.map((a, j) => (
                <Badge key={j} variant="outline" className="border-primary/40 bg-primary/10 text-primary">
                  → {a}
                </Badge>
              ))}
            </div>
          </li>
        ))}
      </ul>
    </SectionCard>
  );
}

function TipsPanel({ plan }: { plan: Plan }) {
  return (
    <SectionCard icon={<Lightbulb className="h-5 w-5" />} title="Smart Optimization" accent="Save money & reduce waste">
      <div className="grid gap-4">
        <TipGroup title="Money-Saving Tips" items={plan.tips.savings} accent="text-success" />
        <TipGroup title="Food Waste Reduction" items={plan.tips.waste} accent="text-warning" />
      </div>
    </SectionCard>
  );
}

function TipGroup({ title, items, accent }: { title: string; items: string[]; accent: string }) {
  return (
    <div>
      <p className={`mb-2 text-xs font-bold uppercase tracking-wider ${accent}`}>{title}</p>
      <ul className="space-y-1.5 text-sm">
        {items.map((t, i) => (
          <li key={i} className="flex gap-2">
            <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${accent.replace("text-", "bg-")}`} />
            <span>{t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ExportBar({ plan, prefs, onReset }: { plan: Plan; prefs: Preferences; onReset: () => void }) {
  return (
    <div className="no-print flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border/60 bg-card/40 p-4 backdrop-blur">
      <div className="flex items-center gap-3 min-w-0">
        <ChefHat className="h-5 w-5 shrink-0 text-primary" />
        <p className="truncate text-sm text-muted-foreground">
          Your personalized plan for {prefs.people} {prefs.people === 1 ? "person" : "people"} is ready.
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" onClick={() => downloadPlanPdf(plan, prefs)}>
          <Download className="mr-1.5 h-4 w-4" />PDF
        </Button>
        <Button variant="outline" size="sm" onClick={() => downloadGroceryTxt(plan, prefs)}>
          <FileText className="mr-1.5 h-4 w-4" />Grocery
        </Button>
        <Button variant="outline" size="sm" onClick={() => window.print()}>
          <Printer className="mr-1.5 h-4 w-4" />Print
        </Button>
        <Button size="sm" onClick={onReset}>New Plan</Button>
      </div>
    </div>
  );
}
