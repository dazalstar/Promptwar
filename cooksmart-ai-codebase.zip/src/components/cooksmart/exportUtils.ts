import { jsPDF } from "jspdf";
import type { Plan, Preferences } from "@/lib/plan.functions";

export function downloadPlanPdf(plan: Plan, prefs: Preferences) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const m = 40;
  let y = m;
  const w = doc.internal.pageSize.getWidth() - m * 2;

  const line = (text: string, size = 11, bold = false) => {
    doc.setFont("helvetica", bold ? "bold" : "normal");
    doc.setFontSize(size);
    const split = doc.splitTextToSize(text, w);
    for (const l of split) {
      if (y > 780) { doc.addPage(); y = m; }
      doc.text(l, m, y);
      y += size + 4;
    }
  };

  line("CookSmart AI — Daily Plan", 20, true);
  line(`${prefs.people} people · ${prefs.diet} · Budget ${prefs.currency} ${prefs.budget}`, 10);
  y += 8;

  (["breakfast", "lunch", "dinner"] as const).forEach((k) => {
    const meal = plan.meals[k];
    line(k.toUpperCase() + ": " + meal.name, 14, true);
    line(`${meal.prepTime} · ${prefs.currency} ${meal.cost.toFixed(2)}`, 10);
    line("Ingredients:", 11, true);
    meal.ingredients.forEach((i) => line(`• ${i.item} — ${i.qty}`));
    line("Steps:", 11, true);
    meal.steps.forEach((s, i) => line(`${i + 1}. ${s}`));
    y += 6;
  });

  line("GROCERY LIST", 14, true);
  plan.grocery.forEach((g) => line(`[${g.category}] ${g.item} — ${g.quantity} (${prefs.currency} ${g.cost.toFixed(2)})`));
  y += 6;
  line(`Total: ${prefs.currency} ${plan.budget.totalCost.toFixed(2)} · Status: ${plan.budget.status}`, 11, true);

  y += 10;
  line("CHECKLIST", 14, true);
  line("Morning:", 11, true); plan.checklist.morning.forEach((t) => line(`☐ ${t}`));
  line("Lunch:", 11, true); plan.checklist.lunch.forEach((t) => line(`☐ ${t}`));
  line("Evening:", 11, true); plan.checklist.evening.forEach((t) => line(`☐ ${t}`));

  doc.save("cooksmart-plan.pdf");
}

export function downloadGroceryTxt(plan: Plan, prefs: Preferences) {
  const lines: string[] = ["CookSmart AI — Grocery List", ""];
  const groups = new Map<string, Plan["grocery"]>();
  for (const g of plan.grocery) {
    if (!groups.has(g.category)) groups.set(g.category, []);
    groups.get(g.category)!.push(g);
  }
  for (const [cat, items] of groups) {
    lines.push(`== ${cat} ==`);
    items.forEach((g) => lines.push(`  [ ] ${g.item} — ${g.quantity} (${prefs.currency} ${g.cost.toFixed(2)})`));
    lines.push("");
  }
  const total = plan.grocery.reduce((s, g) => s + g.cost, 0);
  lines.push(`Total: ${prefs.currency} ${total.toFixed(2)}`);
  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "grocery-list.txt"; a.click();
  URL.revokeObjectURL(url);
}
